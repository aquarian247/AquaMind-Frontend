<template>
  <div class="login-view">
    <div class="login-container">
      <BaseCard class="login-card">
        <template #header>
          <h1 class="login-title">AquaMind</h1>
          <p class="login-subtitle">Aquaculture Management System</p>
        </template>
        
        <form @submit.prevent="handleLogin" class="login-form">
          <BaseInput
            v-model="username"
            label="Username"
            placeholder="Enter your username"
            required
            :error="errors.username"
          />
          
          <BaseInput
            v-model="password"
            type="password"
            label="Password"
            placeholder="Enter your password"
            required
            :error="errors.password"
          />
          
          <div v-if="authStore.error" class="alert alert-error">
            {{ authStore.error }}
          </div>
          
          <BaseButton
            type="submit"
            variant="primary"
            block
            :loading="authStore.loading"
          >
            Log In
          </BaseButton>
        </form>
        
        <template #footer>
          <div class="theme-selector-container">
            <p class="theme-text">Select Theme:</p>
            <ThemeSelector />
          </div>
        </template>
      </BaseCard>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/authStore';
import BaseCard from '@/components/base/BaseCard.vue';
import BaseInput from '@/components/base/BaseInput.vue';
import BaseButton from '@/components/base/BaseButton.vue';
import ThemeSelector from '@/components/ThemeSelector.vue';

const router = useRouter();
const authStore = useAuthStore();

const username = ref('');
const password = ref('');
const errors = ref({
  username: '',
  password: ''
});

const validateForm = () => {
  let isValid = true;
  errors.value = {
    username: '',
    password: ''
  };
  
  if (!username.value.trim()) {
    errors.value.username = 'Username is required';
    isValid = false;
  }
  
  if (!password.value) {
    errors.value.password = 'Password is required';
    isValid = false;
  }
  
  return isValid;
};

const handleLogin = async () => {
  if (!validateForm()) return;
  
  const success = await authStore.login({
    username: username.value,
    password: password.value
  });
  
  if (success) {
    router.push('/dashboard');
  }
};
</script>

<style scoped>
.login-view {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: var(--background);
}

.login-container {
  width: 100%;
  max-width: 400px;
  padding: var(--spacing-md);
}

.login-card {
  width: 100%;
}

.login-title {
  font-size: var(--font-size-xxl);
  color: var(--primary);
  margin: 0;
  text-align: center;
}

.login-subtitle {
  color: var(--text-secondary);
  text-align: center;
  margin-top: var(--spacing-xs);
  margin-bottom: 0;
}

.login-form {
  margin-top: var(--spacing-md);
}

.theme-selector-container {
  display: flex;
  align-items: center;
  justify-content: center;
}

.theme-text {
  margin: 0;
  margin-right: var(--spacing-sm);
  color: var(--text-secondary);
}
</style>
