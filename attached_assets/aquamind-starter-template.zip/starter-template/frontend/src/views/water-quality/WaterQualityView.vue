<template>
  <div class="water-quality-view">
    <h1 class="page-title">Water Quality Monitoring</h1>
    
    <div class="filters-section">
      <BaseCard>
        <div class="filters-container">
          <div class="filter-group">
            <label class="filter-label">Farm</label>
            <select class="form-select">
              <option value="all">All Farms</option>
              <option value="1">North Farm</option>
              <option value="2">South Farm</option>
              <option value="3">East Farm</option>
            </select>
          </div>
          
          <div class="filter-group">
            <label class="filter-label">Pen</label>
            <select class="form-select">
              <option value="all">All Pens</option>
              <option value="1">Pen #1</option>
              <option value="2">Pen #2</option>
              <option value="3">Pen #3</option>
              <option value="4">Pen #4</option>
            </select>
          </div>
          
          <div class="filter-group">
            <label class="filter-label">Date Range</label>
            <div class="date-range">
              <input type="date" class="form-input" value="2023-01-01">
              <span class="date-separator">to</span>
              <input type="date" class="form-input" value="2023-01-07">
            </div>
          </div>
          
          <div class="filter-actions">
            <BaseButton variant="primary">Apply Filters</BaseButton>
            <BaseButton variant="secondary">Reset</BaseButton>
          </div>
        </div>
      </BaseCard>
    </div>
    
    <div class="charts-section">
      <WaterQualityChart 
        :data="waterQualityData" 
        title="Water Quality Trends"
      />
    </div>
    
    <div class="data-section">
      <BaseCard title="Water Quality Records">
        <div class="table-container">
          <table class="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Farm</th>
                <th>Pen</th>
                <th>Temperature (°C)</th>
                <th>Oxygen (mg/L)</th>
                <th>pH</th>
                <th>Salinity (ppt)</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(record, index) in waterQualityData" :key="index">
                <td>{{ formatDate(record.timestamp) }}</td>
                <td>North Farm</td>
                <td>Pen #1</td>
                <td>{{ record.temperature }}</td>
                <td>{{ record.oxygen }}</td>
                <td>{{ record.ph }}</td>
                <td>{{ record.salinity }}</td>
                <td>
                  <div class="action-buttons">
                    <button class="btn-icon" title="Edit">✏️</button>
                    <button class="btn-icon" title="Delete">🗑️</button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div class="pagination">
          <button class="btn-icon">«</button>
          <button class="pagination-number active">1</button>
          <button class="pagination-number">2</button>
          <button class="pagination-number">3</button>
          <button class="btn-icon">»</button>
        </div>
      </BaseCard>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import BaseCard from '@/components/base/BaseCard.vue';
import BaseButton from '@/components/base/BaseButton.vue';
import WaterQualityChart from '@/components/charts/WaterQualityChart.vue';

// Mock data for demonstration
const waterQualityData = ref([
  { timestamp: '2023-01-01', temperature: 12, oxygen: 8.5, ph: 7.2, salinity: 35 },
  { timestamp: '2023-01-02', temperature: 12.2, oxygen: 8.3, ph: 7.3, salinity: 34.8 },
  { timestamp: '2023-01-03', temperature: 12.5, oxygen: 8.2, ph: 7.1, salinity: 34.5 },
  { timestamp: '2023-01-04', temperature: 12.3, oxygen: 8.4, ph: 7.2, salinity: 34.7 },
  { timestamp: '2023-01-05', temperature: 12.1, oxygen: 8.6, ph: 7.3, salinity: 35.1 },
  { timestamp: '2023-01-06', temperature: 12.4, oxygen: 8.5, ph: 7.2, salinity: 35.0 },
  { timestamp: '2023-01-07', temperature: 12.6, oxygen: 8.3, ph: 7.1, salinity: 34.8 }
]);

const formatDate = (dateString) => {
  const date = new Date(dateString);
  return date.toLocaleDateString();
};
</script>

<style scoped>
.water-quality-view {
  padding: var(--spacing-md);
}

.page-title {
  margin-top: 0;
  margin-bottom: var(--spacing-lg);
  font-size: var(--font-size-xxl);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary);
}

.filters-section {
  margin-bottom: var(--spacing-lg);
}

.filters-container {
  display: flex;
  flex-wrap: wrap;
  gap: var(--spacing-md);
  align-items: flex-end;
}

.filter-group {
  flex: 1;
  min-width: 200px;
}

.filter-label {
  display: block;
  margin-bottom: var(--spacing-xs);
  font-weight: var(--font-weight-medium);
  color: var(--text-primary);
}

.form-select {
  width: 100%;
  padding: var(--spacing-sm);
  border: 1px solid var(--border);
  border-radius: var(--border-radius-md);
  background-color: var(--surface);
  color: var(--text-primary);
  font-size: var(--font-size-md);
}

.date-range {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
}

.date-separator {
  color: var(--text-secondary);
}

.filter-actions {
  display: flex;
  gap: var(--spacing-sm);
  align-items: flex-end;
}

.charts-section {
  margin-bottom: var(--spacing-lg);
}

.data-section {
  margin-bottom: var(--spacing-lg);
}

.table-container {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th,
.data-table td {
  padding: var(--spacing-sm);
  text-align: left;
  border-bottom: 1px solid var(--border);
}

.data-table th {
  font-weight: var(--font-weight-semibold);
  color: var(--text-primary);
  background-color: rgba(var(--primary-rgb), 0.05);
}

.data-table tr:hover {
  background-color: rgba(var(--primary-rgb), 0.05);
}

.action-buttons {
  display: flex;
  gap: var(--spacing-xs);
}

.btn-icon {
  background: none;
  border: none;
  cursor: pointer;
  padding: var(--spacing-xs);
  border-radius: var(--border-radius-sm);
  transition: background-color 0.2s ease;
}

.btn-icon:hover {
  background-color: rgba(var(--primary-rgb), 0.1);
}

.pagination {
  display: flex;
  justify-content: center;
  gap: var(--spacing-xs);
  margin-top: var(--spacing-md);
}

.pagination-number {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--border-radius-md);
  border: 1px solid var(--border);
  background: none;
  cursor: pointer;
  transition: all 0.2s ease;
}

.pagination-number:hover {
  border-color: var(--primary);
  color: var(--primary);
}

.pagination-number.active {
  background-color: var(--primary);
  color: white;
  border-color: var(--primary);
}

@media (max-width: 768px) {
  .filters-container {
    flex-direction: column;
    align-items: stretch;
  }
  
  .filter-group {
    width: 100%;
  }
  
  .filter-actions {
    flex-direction: column;
    width: 100%;
  }
}
</style>
