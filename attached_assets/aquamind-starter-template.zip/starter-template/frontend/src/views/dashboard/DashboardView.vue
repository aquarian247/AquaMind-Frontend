<template>
  <div class="dashboard-view">
    <h1 class="page-title">Dashboard</h1>
    
    <div class="dashboard-summary">
      <BaseCard v-for="(stat, index) in summaryStats" :key="index" class="summary-card">
        <div class="stat-content">
          <div class="stat-icon" :class="`bg-${stat.color}`">{{ stat.icon }}</div>
          <div class="stat-info">
            <h3 class="stat-value">{{ stat.value }}</h3>
            <p class="stat-label">{{ stat.label }}</p>
          </div>
        </div>
      </BaseCard>
    </div>
    
    <div class="dashboard-charts">
      <div class="chart-row">
        <WaterQualityChart 
          :data="waterQualityData" 
          title="Water Quality Trends"
          class="dashboard-chart"
        />
      </div>
      
      <div class="chart-row">
        <BaseCard title="Recent Alerts" class="alerts-card">
          <div v-if="alerts.length === 0" class="no-data">
            No recent alerts
          </div>
          <div v-else class="alerts-list">
            <div v-for="(alert, index) in alerts" :key="index" 
                 class="alert-item" :class="`alert-${alert.severity}`">
              <div class="alert-icon">{{ alert.icon }}</div>
              <div class="alert-content">
                <h4 class="alert-title">{{ alert.title }}</h4>
                <p class="alert-message">{{ alert.message }}</p>
                <span class="alert-time">{{ alert.time }}</span>
              </div>
            </div>
          </div>
        </BaseCard>
        
        <BaseCard title="Farm Status" class="status-card">
          <div class="status-list">
            <div v-for="(status, index) in farmStatus" :key="index" class="status-item">
              <div class="status-name">{{ status.name }}</div>
              <div class="status-value" :class="`text-${status.color}`">{{ status.value }}</div>
            </div>
          </div>
        </BaseCard>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import BaseCard from '@/components/base/BaseCard.vue';
import WaterQualityChart from '@/components/charts/WaterQualityChart.vue';

// Mock data for demonstration
const summaryStats = ref([
  { label: 'Active Farms', value: '3', icon: '🏡', color: 'primary' },
  { label: 'Total Pens', value: '24', icon: '🥣', color: 'secondary' },
  { label: 'Salmon Count', value: '12,450', icon: '🐟', color: 'success' },
  { label: 'Feed Stock', value: '4.2 tons', icon: '🍽️', color: 'warning' }
]);

const waterQualityData = ref([
  { timestamp: '2023-01-01', temperature: 12, oxygen: 8.5, ph: 7.2, salinity: 35 },
  { timestamp: '2023-01-02', temperature: 12.2, oxygen: 8.3, ph: 7.3, salinity: 34.8 },
  { timestamp: '2023-01-03', temperature: 12.5, oxygen: 8.2, ph: 7.1, salinity: 34.5 },
  { timestamp: '2023-01-04', temperature: 12.3, oxygen: 8.4, ph: 7.2, salinity: 34.7 },
  { timestamp: '2023-01-05', temperature: 12.1, oxygen: 8.6, ph: 7.3, salinity: 35.1 },
  { timestamp: '2023-01-06', temperature: 12.4, oxygen: 8.5, ph: 7.2, salinity: 35.0 },
  { timestamp: '2023-01-07', temperature: 12.6, oxygen: 8.3, ph: 7.1, salinity: 34.8 }
]);

const alerts = ref([
  { 
    title: 'Low Oxygen Level', 
    message: 'Pen #5 oxygen level below threshold (7.2 mg/L)', 
    time: '2 hours ago',
    severity: 'warning',
    icon: '⚠️'
  },
  { 
    title: 'Temperature Alert', 
    message: 'Pen #3 temperature rising rapidly (14.2°C)', 
    time: '4 hours ago',
    severity: 'error',
    icon: '🔥'
  },
  { 
    title: 'Feed Schedule', 
    message: 'Scheduled feeding for Pen #1-8 completed', 
    time: '6 hours ago',
    severity: 'success',
    icon: '✅'
  }
]);

const farmStatus = ref([
  { name: 'North Farm', value: 'Active', color: 'success' },
  { name: 'South Farm', value: 'Active', color: 'success' },
  { name: 'East Farm', value: 'Maintenance', color: 'warning' }
]);
</script>

<style scoped>
.dashboard-view {
  padding: var(--spacing-md);
}

.page-title {
  margin-top: 0;
  margin-bottom: var(--spacing-lg);
  font-size: var(--font-size-xxl);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary);
}

.dashboard-summary {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: var(--spacing-md);
  margin-bottom: var(--spacing-lg);
}

.summary-card {
  height: 100%;
}

.stat-content {
  display: flex;
  align-items: center;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: var(--border-radius-md);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  margin-right: var(--spacing-md);
}

.stat-info {
  flex: 1;
}

.stat-value {
  margin: 0;
  font-size: var(--font-size-xl);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary);
}

.stat-label {
  margin: 0;
  color: var(--text-secondary);
  font-size: var(--font-size-sm);
}

.dashboard-charts {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-md);
}

.chart-row {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: var(--spacing-md);
}

.dashboard-chart {
  min-height: 350px;
}

.alerts-card, .status-card {
  height: 100%;
}

.alerts-list {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-sm);
}

.alert-item {
  display: flex;
  padding: var(--spacing-sm);
  border-radius: var(--border-radius-md);
  background-color: rgba(var(--primary-rgb), 0.05);
}

.alert-warning {
  background-color: rgba(var(--warning-rgb), 0.1);
}

.alert-error {
  background-color: rgba(var(--error-rgb), 0.1);
}

.alert-success {
  background-color: rgba(var(--success-rgb), 0.1);
}

.alert-icon {
  margin-right: var(--spacing-sm);
  font-size: var(--font-size-lg);
}

.alert-content {
  flex: 1;
}

.alert-title {
  margin: 0;
  font-size: var(--font-size-md);
  font-weight: var(--font-weight-semibold);
}

.alert-message {
  margin: var(--spacing-xs) 0;
  font-size: var(--font-size-sm);
  color: var(--text-secondary);
}

.alert-time {
  font-size: var(--font-size-xs);
  color: var(--text-secondary);
}

.status-list {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-sm);
}

.status-item {
  display: flex;
  justify-content: space-between;
  padding: var(--spacing-sm);
  border-bottom: 1px solid var(--border);
}

.status-item:last-child {
  border-bottom: none;
}

.status-name {
  font-weight: var(--font-weight-medium);
}

.status-value {
  font-weight: var(--font-weight-semibold);
}

.no-data {
  text-align: center;
  padding: var(--spacing-md);
  color: var(--text-secondary);
}

@media (max-width: 768px) {
  .chart-row {
    grid-template-columns: 1fr;
  }
}
</style>
