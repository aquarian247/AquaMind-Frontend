<template>
  <div id="app" :class="themeClass">
    <div class="app-layout">
      <AppSidebar :collapsed="sidebarCollapsed" />
      <div class="app-main">
        <AppHeader @toggle-sidebar="toggleSidebar" />
        <div class="app-content">
          <router-view />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useThemeStore } from './stores/themeStore';
import AppHeader from './components/layout/AppHeader.vue';
import AppSidebar from './components/layout/AppSidebar.vue';

const themeStore = useThemeStore();
const themeClass = computed(() => themeStore.themeClass);

const sidebarCollapsed = ref(false);
const toggleSidebar = () => {
  sidebarCollapsed.value = !sidebarCollapsed.value;
};
</script>
