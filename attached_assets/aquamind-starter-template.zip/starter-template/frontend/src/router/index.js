import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/authStore'
import HomeView from '@/views/HomeView.vue'
import LoginView from '@/views/auth/LoginView.vue'
import DashboardView from '@/views/dashboard/DashboardView.vue'
import WaterQualityView from '@/views/water-quality/WaterQualityView.vue'
import SalmonHealthView from '@/views/salmon-health/SalmonHealthView.vue'
import FeedManagementView from '@/views/feed-management/FeedManagementView.vue'
import SettingsView from '@/views/settings/SettingsView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: DashboardView,
      meta: { requiresAuth: true }
    },
    {
      path: '/water-quality',
      name: 'water-quality',
      component: WaterQualityView,
      meta: { requiresAuth: true }
    },
    {
      path: '/salmon-health',
      name: 'salmon-health',
      component: SalmonHealthView,
      meta: { requiresAuth: true }
    },
    {
      path: '/feed-management',
      name: 'feed-management',
      component: FeedManagementView,
      meta: { requiresAuth: true }
    },
    {
      path: '/settings',
      name: 'settings',
      component: SettingsView,
      meta: { requiresAuth: true }
    }
  ]
})

// Navigation guard
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth)

  if (requiresAuth && !authStore.isAuthenticated()) {
    next('/login')
  } else {
    next()
  }
})

export default router
