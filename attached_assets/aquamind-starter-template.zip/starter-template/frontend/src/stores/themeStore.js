import { defineStore } from 'pinia';
import { ref, computed, watch } from 'vue';

export const useThemeStore = defineStore('theme', () => {
  // State
  const currentTheme = ref(localStorage.getItem('theme') || 'ocean-depths');
  const isDarkMode = ref(localStorage.getItem('darkMode') === 'dark' || 
    (localStorage.getItem('darkMode') === null && 
     window.matchMedia('(prefers-color-scheme: dark)').matches));
  
  // Getters
  const themeClass = computed(() => {
    return `theme-${currentTheme.value}${isDarkMode.value ? '-dark' : '-light'}`;
  });
  
  // Actions
  function setTheme(theme) {
    if (['ocean-depths', 'warm-earth', 'solarized'].includes(theme)) {
      currentTheme.value = theme;
      localStorage.setItem('theme', theme);
      applyTheme();
    }
  }
  
  function toggleDarkMode() {
    isDarkMode.value = !isDarkMode.value;
    localStorage.setItem('darkMode', isDarkMode.value ? 'dark' : 'light');
    applyTheme();
  }
  
  function applyTheme() {
    document.documentElement.className = themeClass.value;
  }
  
  // Initialize theme on store creation
  watch(
    [currentTheme, isDarkMode],
    () => applyTheme(),
    { immediate: true }
  );
  
  return {
    currentTheme,
    isDarkMode,
    themeClass,
    setTheme,
    toggleDarkMode
  };
});
