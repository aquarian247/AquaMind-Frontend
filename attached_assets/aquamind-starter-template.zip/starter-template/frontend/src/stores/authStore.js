import { defineStore } from 'pinia';
import { ref } from 'vue';
import axios from 'axios';

export const useAuthStore = defineStore('auth', () => {
  // State
  const token = ref(localStorage.getItem('token') || null);
  const user = ref(JSON.parse(localStorage.getItem('user') || 'null'));
  const loading = ref(false);
  const error = ref(null);
  
  // Getters
  const isAuthenticated = () => !!token.value;
  
  // Actions
  async function login(credentials) {
    loading.value = true;
    error.value = null;
    
    try {
      const response = await axios.post('/api/auth/token/', credentials);
      token.value = response.data.access;
      user.value = response.data.user;
      
      localStorage.setItem('token', token.value);
      localStorage.setItem('user', JSON.stringify(user.value));
      
      return true;
    } catch (err) {
      error.value = err.response?.data?.detail || 'Login failed. Please check your credentials.';
      return false;
    } finally {
      loading.value = false;
    }
  }
  
  async function refreshToken() {
    try {
      const response = await axios.post('/api/auth/token/refresh/');
      token.value = response.data.access;
      localStorage.setItem('token', token.value);
      return true;
    } catch (err) {
      logout();
      return false;
    }
  }
  
  function logout() {
    token.value = null;
    user.value = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
  
  return {
    token,
    user,
    loading,
    error,
    isAuthenticated,
    login,
    refreshToken,
    logout
  };
});
