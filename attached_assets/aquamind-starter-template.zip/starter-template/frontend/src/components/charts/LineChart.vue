<template>
  <div class="chart-container">
    <h3 v-if="title" class="chart-title">{{ title }}</h3>
    <Line
      :data="chartData"
      :options="chartOptions"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import { Line } from 'vue-chartjs';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { useThemeStore } from '@/stores/themeStore';

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const props = defineProps({
  title: {
    type: String,
    default: ''
  },
  data: {
    type: Array,
    required: true
  },
  labels: {
    type: Array,
    default: () => []
  },
  datasets: {
    type: Array,
    required: true
  }
});

const themeStore = useThemeStore();

// Get CSS variables for current theme
const getThemeColors = () => {
  const style = getComputedStyle(document.documentElement);
  return {
    primary: style.getPropertyValue('--primary').trim(),
    secondary: style.getPropertyValue('--secondary').trim(),
    success: style.getPropertyValue('--success').trim(),
    warning: style.getPropertyValue('--warning').trim(),
    error: style.getPropertyValue('--error').trim(),
    info: style.getPropertyValue('--info').trim(),
    textPrimary: style.getPropertyValue('--text-primary').trim(),
    background: style.getPropertyValue('--background').trim(),
    surface: style.getPropertyValue('--surface').trim(),
    border: style.getPropertyValue('--border').trim(),
  };
};

const themeColors = ref(getThemeColors());

// Update colors when theme changes
watch(
  () => [themeStore.currentTheme, themeStore.isDarkMode],
  () => {
    themeColors.value = getThemeColors();
  }
);

const chartData = computed(() => {
  const chartLabels = props.labels.length > 0 ? props.labels : props.data.map((_, index) => `Item ${index + 1}`);
  
  const colors = [
    themeColors.value.primary,
    themeColors.value.secondary,
    themeColors.value.success,
    themeColors.value.warning,
    themeColors.value.error,
    themeColors.value.info
  ];
  
  const chartDatasets = props.datasets.map((dataset, index) => ({
    ...dataset,
    borderColor: dataset.borderColor || colors[index % colors.length],
    backgroundColor: dataset.backgroundColor || colors[index % colors.length] + '20',
    tension: dataset.tension || 0.3
  }));
  
  return {
    labels: chartLabels,
    datasets: chartDatasets
  };
});

const chartOptions = computed(() => {
  return {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          color: themeColors.value.border
        },
        ticks: {
          color: themeColors.value.textPrimary
        }
      },
      x: {
        grid: {
          color: themeColors.value.border
        },
        ticks: {
          color: themeColors.value.textPrimary
        }
      }
    },
    plugins: {
      legend: {
        labels: {
          color: themeColors.value.textPrimary
        }
      },
      tooltip: {
        backgroundColor: themeColors.value.surface,
        titleColor: themeColors.value.textPrimary,
        bodyColor: themeColors.value.textPrimary,
        borderColor: themeColors.value.border,
        borderWidth: 1
      }
    }
  };
});

onMounted(() => {
  themeColors.value = getThemeColors();
});
</script>

<style scoped>
.chart-container {
  position: relative;
  height: 300px;
  width: 100%;
}

.chart-title {
  margin-top: 0;
  margin-bottom: var(--spacing-md);
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-semibold);
  color: var(--text-primary);
}
</style>
