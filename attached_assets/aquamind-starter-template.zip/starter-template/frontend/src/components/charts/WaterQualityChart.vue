<template>
  <div class="water-quality-chart">
    <BaseCard :title="title">
      <LineChart
        :data="chartData"
        :datasets="datasets"
        :labels="labels"
      />
    </BaseCard>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import BaseCard from '@/components/base/BaseCard.vue';
import LineChart from '@/components/charts/LineChart.vue';

const props = defineProps({
  title: {
    type: String,
    default: 'Water Quality Metrics'
  },
  data: {
    type: Array,
    required: true
  }
});

const labels = computed(() => {
  return props.data.map(item => {
    const date = new Date(item.timestamp);
    return date.toLocaleDateString();
  });
});

const datasets = computed(() => {
  return [
    {
      label: 'Temperature (°C)',
      data: props.data.map(item => item.temperature),
    },
    {
      label: 'Oxygen (mg/L)',
      data: props.data.map(item => item.oxygen),
    },
    {
      label: 'pH',
      data: props.data.map(item => item.ph),
    },
    {
      label: 'Salinity (ppt)',
      data: props.data.map(item => item.salinity),
    }
  ];
});

const chartData = computed(() => props.data);
</script>
