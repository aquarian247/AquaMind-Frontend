<template>
  <header class="app-header">
    <div class="header-left">
      <button class="btn-icon" @click="$emit('toggle-sidebar')">
        <span class="icon">☰</span>
      </button>
      <h1 class="app-title">AquaMind</h1>
    </div>
    <div class="header-right">
      <ThemeSelector />
      <div class="user-menu" v-if="authStore.isAuthenticated()">
        <span class="user-name">{{ authStore.user?.username }}</span>
        <button class="btn btn-sm" @click="logout">Logout</button>
      </div>
    </div>
  </header>
</template>

<script setup>
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/authStore';
import ThemeSelector from '@/components/ThemeSelector.vue';

const router = useRouter();
const authStore = useAuthStore();

const logout = () => {
  authStore.logout();
  router.push('/login');
};
</script>

<style scoped>
.app-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 60px;
  padding: 0 var(--spacing-md);
  background-color: var(--surface);
  border-bottom: 1px solid var(--border);
}

.header-left, .header-right {
  display: flex;
  align-items: center;
}

.app-title {
  margin: 0;
  margin-left: var(--spacing-md);
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-semibold);
}

.btn-icon {
  background: none;
  border: none;
  color: var(--text-primary);
  font-size: var(--font-size-lg);
  cursor: pointer;
  padding: var(--spacing-xs);
  border-radius: var(--border-radius-md);
}

.btn-icon:hover {
  background-color: rgba(var(--text-primary-rgb), 0.1);
}

.user-menu {
  display: flex;
  align-items: center;
  margin-left: var(--spacing-md);
}

.user-name {
  margin-right: var(--spacing-sm);
  font-weight: var(--font-weight-medium);
}
</style>
