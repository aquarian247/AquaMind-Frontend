<template>
  <nav class="app-sidebar" :class="{ collapsed }">
    <div class="sidebar-header">
      <div class="logo" v-if="!collapsed">AquaMind</div>
      <div class="logo-small" v-else>AM</div>
    </div>
    <ul class="sidebar-menu">
      <li v-for="item in menuItems" :key="item.path">
        <router-link :to="item.path" :title="item.name">
          <span class="menu-icon">{{ item.icon }}</span>
          <span class="menu-text" v-if="!collapsed">{{ item.name }}</span>
        </router-link>
      </li>
    </ul>
  </nav>
</template>

<script setup>
import { defineProps } from 'vue';

const props = defineProps({
  collapsed: {
    type: Boolean,
    default: false
  }
});

const menuItems = [
  { name: 'Dashboard', path: '/dashboard', icon: '📊' },
  { name: 'Water Quality', path: '/water-quality', icon: '💧' },
  { name: 'Salmon Health', path: '/salmon-health', icon: '🐟' },
  { name: 'Feed Management', path: '/feed-management', icon: '🍽️' },
  { name: 'Settings', path: '/settings', icon: '⚙️' }
];
</script>

<style scoped>
.app-sidebar {
  width: 250px;
  background-color: var(--surface);
  border-right: 1px solid var(--border);
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.app-sidebar.collapsed {
  width: 60px;
}

.sidebar-header {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid var(--border);
  padding: 0 var(--spacing-md);
}

.logo {
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-bold);
  color: var(--primary);
}

.logo-small {
  font-size: var(--font-size-md);
  font-weight: var(--font-weight-bold);
  color: var(--primary);
}

.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
}

.sidebar-menu li {
  margin: 0;
  padding: 0;
}

.sidebar-menu a {
  display: flex;
  align-items: center;
  padding: var(--spacing-md);
  color: var(--text-primary);
  text-decoration: none;
  transition: background-color 0.2s ease;
}

.sidebar-menu a:hover {
  background-color: rgba(var(--primary-rgb), 0.1);
}

.sidebar-menu a.router-link-active {
  background-color: rgba(var(--primary-rgb), 0.15);
  color: var(--primary);
  font-weight: var(--font-weight-medium);
}

.menu-icon {
  margin-right: var(--spacing-md);
  font-size: var(--font-size-lg);
}

.collapsed .menu-icon {
  margin-right: 0;
}

@media (max-width: 768px) {
  .app-sidebar {
    width: 100%;
    height: auto;
  }
  
  .app-sidebar.collapsed {
    height: 60px;
    overflow: hidden;
  }
  
  .sidebar-menu {
    flex-direction: row;
    display: flex;
    overflow-x: auto;
  }
  
  .sidebar-menu a {
    padding: var(--spacing-sm);
  }
}
</style>
