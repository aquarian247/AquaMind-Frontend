<template>
  <div class="theme-selector">
    <div class="theme-options">
      <button 
        @click="setTheme('ocean-depths')" 
        :class="{ active: currentTheme === 'ocean-depths' }"
        class="theme-btn ocean-depths"
        title="Ocean Depths"
      >
        <span class="theme-icon">🌊</span>
      </button>
      <button 
        @click="setTheme('warm-earth')" 
        :class="{ active: currentTheme === 'warm-earth' }"
        class="theme-btn warm-earth"
        title="Warm Earth"
      >
        <span class="theme-icon">🌄</span>
      </button>
      <button 
        @click="setTheme('solarized')" 
        :class="{ active: currentTheme === 'solarized' }"
        class="theme-btn solarized"
        title="Solarized"
      >
        <span class="theme-icon">☀️</span>
      </button>
    </div>
    <button @click="toggleDarkMode" class="mode-toggle" :title="isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'">
      <span v-if="isDarkMode">🌞</span>
      <span v-else>🌙</span>
    </button>
  </div>
</template>

<script setup>
import { useThemeStore } from '@/stores/themeStore';
import { storeToRefs } from 'pinia';

const themeStore = useThemeStore();
const { currentTheme, isDarkMode } = storeToRefs(themeStore);
const { setTheme, toggleDarkMode } = themeStore;
</script>

<style scoped>
.theme-selector {
  display: flex;
  align-items: center;
}

.theme-options {
  display: flex;
  margin-right: var(--spacing-sm);
}

.theme-btn {
  background: none;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: var(--border-radius-md);
  margin-right: var(--spacing-xs);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
}

.theme-btn:hover {
  background-color: rgba(var(--text-primary-rgb), 0.1);
}

.theme-btn.active {
  background-color: rgba(var(--primary-rgb), 0.2);
  color: var(--primary);
}

.theme-icon {
  font-size: var(--font-size-md);
}

.mode-toggle {
  background: none;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: var(--border-radius-md);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
}

.mode-toggle:hover {
  background-color: rgba(var(--text-primary-rgb), 0.1);
}
</style>
