<template>
  <div class="form-group">
    <label v-if="label" :for="id" class="form-label">{{ label }}</label>
    <input
      :id="id"
      :type="type"
      :value="modelValue"
      :placeholder="placeholder"
      :disabled="disabled"
      :required="required"
      :class="['base-input', { 'is-invalid': error }]"
      @input="$emit('update:modelValue', $event.target.value)"
    />
    <div v-if="error" class="error-message">{{ error }}</div>
    <div v-if="helpText" class="help-text">{{ helpText }}</div>
  </div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  modelValue: {
    type: [String, Number],
    default: ''
  },
  label: {
    type: String,
    default: ''
  },
  type: {
    type: String,
    default: 'text'
  },
  placeholder: {
    type: String,
    default: ''
  },
  disabled: {
    type: Boolean,
    default: false
  },
  required: {
    type: Boolean,
    default: false
  },
  error: {
    type: String,
    default: ''
  },
  helpText: {
    type: String,
    default: ''
  },
  id: {
    type: String,
    default: () => `input-${Math.random().toString(36).substring(2, 9)}`
  }
});

defineEmits(['update:modelValue']);
</script>

<style scoped>
.form-group {
  margin-bottom: var(--spacing-md);
}

.form-label {
  display: block;
  margin-bottom: var(--spacing-xs);
  font-weight: var(--font-weight-medium);
  color: var(--text-primary);
}

.base-input {
  width: 100%;
  padding: var(--spacing-sm);
  border: 1px solid var(--border);
  border-radius: var(--border-radius-md);
  background-color: var(--surface);
  color: var(--text-primary);
  font-size: var(--font-size-md);
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.base-input:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 2px rgba(var(--primary-rgb), 0.2);
}

.base-input:disabled {
  background-color: rgba(var(--text-disabled-rgb), 0.1);
  cursor: not-allowed;
}

.base-input.is-invalid {
  border-color: var(--error);
}

.base-input.is-invalid:focus {
  box-shadow: 0 0 0 2px rgba(var(--error-rgb), 0.2);
}

.error-message {
  color: var(--error);
  font-size: var(--font-size-sm);
  margin-top: var(--spacing-xs);
}

.help-text {
  color: var(--text-secondary);
  font-size: var(--font-size-sm);
  margin-top: var(--spacing-xs);
}
</style>
