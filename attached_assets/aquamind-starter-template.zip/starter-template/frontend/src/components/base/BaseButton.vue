<template>
  <button
    :class="[
      'base-button',
      `variant-${variant}`,
      `size-${size}`,
      { 'is-disabled': disabled, 'is-loading': loading, 'is-block': block }
    ]"
    :disabled="disabled || loading"
    :type="type"
    @click="handleClick"
  >
    <span v-if="loading" class="loading-spinner"></span>
    <span class="button-content" :class="{ 'is-hidden': loading }">
      <slot></slot>
    </span>
  </button>
</template>

<script setup>
const props = defineProps({
  variant: {
    type: String,
    default: 'primary',
    validator: (value) => ['primary', 'secondary', 'success', 'warning', 'error', 'info', 'text'].includes(value)
  },
  size: {
    type: String,
    default: 'medium',
    validator: (value) => ['small', 'medium', 'large'].includes(value)
  },
  disabled: {
    type: Boolean,
    default: false
  },
  loading: {
    type: Boolean,
    default: false
  },
  block: {
    type: Boolean,
    default: false
  },
  type: {
    type: String,
    default: 'button'
  }
});

const emit = defineEmits(['click']);

const handleClick = (event) => {
  if (!props.disabled && !props.loading) {
    emit('click', event);
  }
};
</script>

<style scoped>
.base-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--border-radius-md);
  font-weight: var(--font-weight-medium);
  cursor: pointer;
  transition: all 0.2s ease;
  border: none;
  position: relative;
  overflow: hidden;
}

/* Variants */
.variant-primary {
  background-color: var(--primary);
  color: white;
}

.variant-primary:hover:not(.is-disabled):not(:disabled) {
  background-color: var(--primary-hover);
}

.variant-secondary {
  background-color: var(--secondary);
  color: white;
}

.variant-secondary:hover:not(.is-disabled):not(:disabled) {
  background-color: var(--secondary-hover);
}

.variant-success {
  background-color: var(--success);
  color: white;
}

.variant-success:hover:not(.is-disabled):not(:disabled) {
  filter: brightness(90%);
}

.variant-warning {
  background-color: var(--warning);
  color: var(--text-primary);
}

.variant-warning:hover:not(.is-disabled):not(:disabled) {
  filter: brightness(90%);
}

.variant-error {
  background-color: var(--error);
  color: white;
}

.variant-error:hover:not(.is-disabled):not(:disabled) {
  filter: brightness(90%);
}

.variant-info {
  background-color: var(--info);
  color: white;
}

.variant-info:hover:not(.is-disabled):not(:disabled) {
  filter: brightness(90%);
}

.variant-text {
  background-color: transparent;
  color: var(--primary);
}

.variant-text:hover:not(.is-disabled):not(:disabled) {
  background-color: rgba(var(--primary-rgb), 0.1);
}

/* Sizes */
.size-small {
  padding: var(--spacing-xs) var(--spacing-sm);
  font-size: var(--font-size-sm);
}

.size-medium {
  padding: var(--spacing-sm) var(--spacing-md);
  font-size: var(--font-size-md);
}

.size-large {
  padding: var(--spacing-md) var(--spacing-lg);
  font-size: var(--font-size-lg);
}

/* States */
.is-disabled, :disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.is-loading {
  cursor: wait;
}

.is-block {
  display: flex;
  width: 100%;
}

.loading-spinner {
  width: 1em;
  height: 1em;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: white;
  animation: spin 1s linear infinite;
  position: absolute;
}

.button-content.is-hidden {
  visibility: hidden;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
</style>
