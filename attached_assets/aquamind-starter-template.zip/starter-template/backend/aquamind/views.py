from rest_framework import viewsets, permissions, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django.contrib.auth.models import User
from django_filters.rest_framework import DjangoFilterBackend
from .models import Farm, Pen, WaterQuality, SalmonHealth, FeedingSchedule, Alert
from .serializers import (
    UserSerializer, FarmSerializer, PenSerializer, 
    WaterQualitySerializer, SalmonHealthSerializer, 
    FeedingScheduleSerializer, AlertSerializer
)

class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

class FarmViewSet(viewsets.ModelViewSet):
    queryset = Farm.objects.all()
    serializer_class = FarmSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'location']
    ordering_fields = ['name', 'created_at']
    
    @action(detail=True, methods=['get'])
    def pens(self, request, pk=None):
        farm = self.get_object()
        pens = Pen.objects.filter(farm=farm)
        serializer = PenSerializer(pens, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def alerts(self, request, pk=None):
        farm = self.get_object()
        alerts = Alert.objects.filter(farm=farm)
        serializer = AlertSerializer(alerts, many=True)
        return Response(serializer.data)

class PenViewSet(viewsets.ModelViewSet):
    queryset = Pen.objects.all()
    serializer_class = PenSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['farm']
    search_fields = ['name']
    ordering_fields = ['name', 'created_at']
    
    @action(detail=True, methods=['get'])
    def water_quality(self, request, pk=None):
        pen = self.get_object()
        records = WaterQuality.objects.filter(pen=pen)
        serializer = WaterQualitySerializer(records, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def salmon_health(self, request, pk=None):
        pen = self.get_object()
        records = SalmonHealth.objects.filter(pen=pen)
        serializer = SalmonHealthSerializer(records, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def feeding_schedules(self, request, pk=None):
        pen = self.get_object()
        schedules = FeedingSchedule.objects.filter(pen=pen)
        serializer = FeedingScheduleSerializer(schedules, many=True)
        return Response(serializer.data)

class WaterQualityViewSet(viewsets.ModelViewSet):
    queryset = WaterQuality.objects.all()
    serializer_class = WaterQualitySerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['pen', 'pen__farm']
    ordering_fields = ['timestamp', 'temperature', 'oxygen', 'ph', 'salinity']
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class SalmonHealthViewSet(viewsets.ModelViewSet):
    queryset = SalmonHealth.objects.all()
    serializer_class = SalmonHealthSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['pen', 'pen__farm', 'health_status']
    ordering_fields = ['timestamp', 'average_weight', 'mortality_count']
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class FeedingScheduleViewSet(viewsets.ModelViewSet):
    queryset = FeedingSchedule.objects.all()
    serializer_class = FeedingScheduleSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['pen', 'pen__farm', 'completed']
    ordering_fields = ['scheduled_time', 'completed']
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    @action(detail=True, methods=['post'])
    def mark_completed(self, request, pk=None):
        schedule = self.get_object()
        schedule.completed = True
        schedule.completed_by = request.user
        schedule.save()
        serializer = self.get_serializer(schedule)
        return Response(serializer.data)

class AlertViewSet(viewsets.ModelViewSet):
    queryset = Alert.objects.all()
    serializer_class = AlertSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['farm', 'pen', 'severity', 'resolved']
    ordering_fields = ['timestamp', 'severity']
    
    @action(detail=True, methods=['post'])
    def resolve(self, request, pk=None):
        alert = self.get_object()
        alert.resolved = True
        alert.resolved_by = request.user
        alert.save()
        serializer = self.get_serializer(alert)
        return Response(serializer.data)
