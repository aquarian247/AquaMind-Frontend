from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Farm, Pen, WaterQuality, SalmonHealth, FeedingSchedule, Alert

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']

class FarmSerializer(serializers.ModelSerializer):
    class Meta:
        model = Farm
        fields = '__all__'

class PenSerializer(serializers.ModelSerializer):
    farm_name = serializers.ReadOnlyField(source='farm.name')
    
    class Meta:
        model = Pen
        fields = '__all__'

class WaterQualitySerializer(serializers.ModelSerializer):
    pen_name = serializers.ReadOnlyField(source='pen.name')
    farm_name = serializers.ReadOnlyField(source='pen.farm.name')
    created_by_username = serializers.ReadOnlyField(source='created_by.username')
    
    class Meta:
        model = WaterQuality
        fields = '__all__'

class SalmonHealthSerializer(serializers.ModelSerializer):
    pen_name = serializers.ReadOnlyField(source='pen.name')
    farm_name = serializers.ReadOnlyField(source='pen.farm.name')
    created_by_username = serializers.ReadOnlyField(source='created_by.username')
    
    class Meta:
        model = SalmonHealth
        fields = '__all__'

class FeedingScheduleSerializer(serializers.ModelSerializer):
    pen_name = serializers.ReadOnlyField(source='pen.name')
    farm_name = serializers.ReadOnlyField(source='pen.farm.name')
    created_by_username = serializers.ReadOnlyField(source='created_by.username')
    completed_by_username = serializers.ReadOnlyField(source='completed_by.username')
    
    class Meta:
        model = FeedingSchedule
        fields = '__all__'

class AlertSerializer(serializers.ModelSerializer):
    farm_name = serializers.ReadOnlyField(source='farm.name')
    pen_name = serializers.ReadOnlyField(source='pen.name')
    resolved_by_username = serializers.ReadOnlyField(source='resolved_by.username')
    
    class Meta:
        model = Alert
        fields = '__all__'
