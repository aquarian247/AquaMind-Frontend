from django.db import models
from django.contrib.auth.models import User

class Farm(models.Model):
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name

class Pen(models.Model):
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='pens')
    name = models.CharField(max_length=100)
    capacity = models.IntegerField()
    current_population = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.farm.name} - {self.name}"

class WaterQuality(models.Model):
    pen = models.ForeignKey(Pen, on_delete=models.CASCADE, related_name='water_quality_records')
    timestamp = models.DateTimeField()
    temperature = models.FloatField()
    oxygen = models.FloatField()
    ph = models.FloatField()
    salinity = models.FloatField()
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"{self.pen} - {self.timestamp}"

class SalmonHealth(models.Model):
    HEALTH_STATUS_CHOICES = [
        ('healthy', 'Healthy'),
        ('concerning', 'Concerning'),
        ('critical', 'Critical'),
    ]
    
    pen = models.ForeignKey(Pen, on_delete=models.CASCADE, related_name='salmon_health_records')
    timestamp = models.DateTimeField()
    average_weight = models.FloatField()
    mortality_count = models.IntegerField(default=0)
    health_status = models.CharField(max_length=20, choices=HEALTH_STATUS_CHOICES, default='healthy')
    notes = models.TextField(blank=True, null=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"{self.pen} - {self.timestamp}"

class FeedingSchedule(models.Model):
    pen = models.ForeignKey(Pen, on_delete=models.CASCADE, related_name='feeding_schedules')
    feed_type = models.CharField(max_length=100)
    amount = models.FloatField()  # in kg
    scheduled_time = models.DateTimeField()
    completed = models.BooleanField(default=False)
    completed_at = models.DateTimeField(null=True, blank=True)
    completed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='completed_feedings')
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_feedings')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-scheduled_time']
    
    def __str__(self):
        return f"{self.pen} - {self.scheduled_time}"

class Alert(models.Model):
    SEVERITY_CHOICES = [
        ('info', 'Information'),
        ('warning', 'Warning'),
        ('error', 'Error'),
        ('critical', 'Critical'),
    ]
    
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='alerts')
    pen = models.ForeignKey(Pen, on_delete=models.CASCADE, related_name='alerts', null=True, blank=True)
    title = models.CharField(max_length=100)
    message = models.TextField()
    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='resolved_alerts')
    
    class Meta:
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"{self.title} - {self.timestamp}"
